

<?php $__env->startSection('main'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Pengaduan</h1>
        <button type="button" class="btn btn-primary btn-sm d-block ml-auto" data-bs-toggle="modal" data-bs-target="#inputPengaduan">
            <i class="fas fa-plus"></i>&nbsp;&nbsp;INPUT
        </button>
    </div>

    <?php if(session()->has('success')): ?>
        <input type="hidden" id="notifSuccess" value="<?php echo e(session()->get('success')); ?>">
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr class="fw-bold">
                    <td scope="col">#</td>
                    <td scope="col">Status</td>
                    <td scope="col">Tanggal Aduan</td>
                    <td>Instansi yang Diadukan</td>
                    <td scope="col">Nama</td>
                    <td scope="col">Alamat</td>
                    <td scope="col">Nomor HP</td>
                    <td scope="col">Isi Aduan</td>
                    <td scope="col">Penginput</td>
                    <td scope="col">Samarkan Identitas</td>
                    <td scope="col">#</td>
                </tr>
            </thead>
            <tbody>
                <?php if(!$instansi->isEmpty()): ?>
                    <?php $__currentLoopData = $aduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="col"><?php echo e($aduan->firstItem() + $loop->index); ?></td>
                            <td scope="col">
                                <div class="<?php if($ad->status->id == 1): ?> bg-primary text-white <?php elseif($ad->status->id == 2): ?> bg-warning <?php elseif($ad->status->id == 3): ?> bg-success <?php endif; ?> rounded-pill px-2 text-center">
                                    <?php echo e($ad->status->status); ?>

                                </div>
                            </td>
                            <td scope="col"><?php echo e(date_format(date_create($ad['tgl_aduan']), 'd/m/Y')); ?></td>
                            <td>
                                <?php if($ad->instansi): ?>
                                    <?php echo e($ad->instansi->nama_instansi); ?>

                                <?php else: ?>
                                    <i>(Instansi dihapus dari sistem)</i>
                                <?php endif; ?>
                            </td>
                            <td scope="col"><?php echo e($ad['nama']); ?></td>
                            <td scope="col"><?php echo e($ad['alamat']); ?></td>
                            <td scope="col"><?php echo e($ad['telepon']); ?></td>
                            <td scope="col"><?php echo nl2br($ad['aduan']); ?></td>
                            <td scope="col"><?php echo e($ad['penginput']); ?></td>
                            <td scope="col">
                                <?php if($ad->samarkan): ?>
                                    Ya
                                <?php else: ?>
                                    Tidak
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-danger editButton" class="btn btn-primary" data-id-aduan=<?php echo e($ad['id']); ?>>
                                    <i class="far fa-share-square"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center"><i class="text-muted">
                                Tidak Ada Data
                            </i>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($aduan->links()); ?>


    <div class="modal fade" id="inputPengaduan" tabindex="-1" aria-labelledby="inputPengaduanLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <form action="/pengaduan" method="POST" enctype="multipart/form-data" id="formAduanAdmin">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="penginput" value="admin">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="inputPengaduanLabel">Input Permohonan</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <div class="form-label" style="margin-bottom: 12px">Jenis Permohonan</div>
                                        <div class="form-check form-check-inline me-5">
                                            <input class="form-check-input" type="radio" name="jenisAduan" id="jenisAduan1" value=1>
                                            <label class="form-check-label" for="jenisAduan1">
                                                PENGADUAN
                                            </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="jenisAduan" id="jenisAduan2" value=0 checked>
                                            <label class="form-check-label" for="jenisAduan2">
                                                INFORMASI
                                            </label>
                                        </div>
                                    </div>
                                    <div class="mb-2">
                                        <label for="tgl_aduan" class="form-label">Tanggal Permohonan</label>
                                        <input type="date" class="form-control" id="tgl_aduan" name="tgl_aduan" max="<?php echo e(date('Y-m-d')); ?>" required>
                                    </div>
                                    <div class="mb-2">
                                        <label for="instansi" class="form-label">Instansi yang Ditanyakan</label>
                                        <select class="form-select" name="instansi" id="instansi">
                                            <option selected>Choose...</option>
                                            <?php $__currentLoopData = $instansi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($i->id); ?>"><?php echo e($i->nama_instansi); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="mb-2">
                                        <label for="nama" class="form-label">Nama</label>
                                        <input type="text" class="form-control" id="nama" name="nama" required>
                                    </div>
                                    <div class="mb-2">
                                        <label for="nohp" class="form-label">No. Hp (Whatsapp)</label>
                                        <input type="tel" pattern="[0-9]{1}[8]{1}-[0-9]{7-11}" class="form-control" id="nohp" name="nohp" required placeholder="08xxxxxxx">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-2">
                                        <label for="alamat" class="form-label">Alamat</label>
                                        <input type="text" class="form-control" id="alamat" name="alamat" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="isi_aduan" class="form-label">Isi Pertanyaan</label>
                                        <textarea type="text" class="form-control" id="isi_aduan" name="isi_aduan" required></textarea>
                                    </div>
                                    <div class="input-group mb-1">
                                        <label class="input-group-text" for="bukti">Bukti Dukung</label>
                                        <input type="file" class="form-control" id="bukti" name="bukti" accept="image/png, image/jpeg">
                                    </div>
                                    <div class="small fst-italic text-end mb-3">
                                        format .jpg, .png, .pdf - maks. 3MB
                                    </div>
                                    <div class="input-group mb-1">
                                        <label class="input-group-text" for="kertas">Kertas Aduan</label>
                                        <input type="file" class="form-control" id="kertas" name="kertas" accept="image/png, image/jpeg" required>
                                    </div>
                                    <div class="small fst-italic text-end">
                                        format foto (.jpg, .png) - maks. 3MB
                                    </div>
                                    <div class="mb-3 mt-4 ps-1">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value=1 id="samarkan" name="samarkan" checked>
                                            <label class="form-check-label fw-bold" for="samarkan">
                                                SAMARKAN IDENTITAS
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" id="kirimAduanAdmin">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true" data-bs-focus="false">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <form method="POST" id="formActionAduan">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="editModalLabel">Data Pengaduan</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-6">
                                    <input type="hidden" name="data_id_aduan" id="data_id_aduan">
                                    <input type="hidden" name="data_jawaban" id="data_jawaban">
                                    <div class="mb-2">
                                        <label for="data_tgl_aduan" class="form-label">Tanggal Aduan</label>
                                        <input type="text" class="form-control" id="data_tgl_aduan" name="data_tgl_aduan" readonly>
                                    </div>
                                    <div class="mb-2">
                                        <label for="data_instansi" class="form-label">Instansi yang diadukan</label>
                                        <div id="list_instansi">
                                        </div>
                                    </div>
                                    <div class="mb-2">
                                        <label for="data_nama" class="form-label">Nama</label>
                                        <input type="text" class="form-control" id="data_nama" name="data_nama" readonly>
                                    </div>
                                    <div class="mb-2">
                                        <label for="data_nohp" class="form-label">No. Hp (Whatsapp)</label>
                                        <input type="text" class="form-control" id="data_nohp" name="data_nohp" readonly placeholder="08xxxxxxx">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-2">
                                        <label for="data_alamat" class="form-label">Alamat</label>
                                        <input type="text" class="form-control" id="data_alamat" name="data_alamat" readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label for="data_isi_aduan" class="form-label">Isi Aduan</label>
                                        <textarea type="text" class="form-control" id="data_isi_aduan" name="data_isi_aduan" readonly style="height: 115px"></textarea>
                                    </div>
                                    <div id="docBuktiDukung"></div>
                                    <div id="docBukti"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="container-fluid">
                            <div class="row" id="buttonAksiAduan">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pengaduan-mpp\resources\views/pengaduan.blade.php ENDPATH**/ ?>