                <!-- Nav Item - Dashboard -->
                <li class="nav-item <?php echo e(request()->is('dashboard') ? 'active' : ''); ?>">
                    <a class="nav-link" href="dashboard">
                        <i class="fas fa-fw fa-tachometer-alt"></i>
                        <span>Dashboard</span></a>
                </li>

                <!-- Divider -->
                <hr class="sidebar-divider my-1">

                <li class="nav-item <?php echo e(request()->is('pengaduan') ? 'active' : ''); ?>">
                    <a class="nav-link" href="pengaduan">
                        <i class="fas fa-edit"></i>
                        <span>Pengaduan</span></a>
                </li>

                <hr class="sidebar-divider my-1">

                <li class="nav-item <?php echo e(request()->is('manajemen-instansi') ? 'active' : ''); ?>">
                    <a class="nav-link" href="manajemen-instansi">
                        <i class="fas fa-city"></i>
                        <span>Manajemen Instansi</span></a>
                </li>

                <hr class="sidebar-divider my-1">

                

                <hr class="sidebar-divider my-1">

                <li class="nav-item <?php echo e(request()->is('manajemen-pengguna') ? 'active' : ''); ?>">
                    <a class="nav-link px-2" href="/form">
                        <div class="bg-white text-primary rounded py-1 text-center fw-bold">
                            <i class="fa fa-list-alt text-primary"></i>
                            <span>FORM PENGADUAN</span>
                        </div>
                    </a>
                </li>


                <!-- Divider -->
                <hr class="sidebar-divider">

                <!-- Sidebar Toggler (Sidebar) -->
                <div class="text-center d-none d-md-inline">
                    <button class="rounded-circle border-0" id="sidebarToggle"></button>
                </div>

                </ul>
                <!-- End of Sidebar -->
<?php /**PATH C:\laragon\www\pengaduan-mpp\resources\views/dashboard/sidebar.blade.php ENDPATH**/ ?>