

<?php $__env->startSection('main'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pengaduan-mpp\resources\views/tes.blade.php ENDPATH**/ ?>