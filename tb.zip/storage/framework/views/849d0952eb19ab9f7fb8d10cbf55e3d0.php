<?php echo $__env->make('dashboard/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <?php echo $__env->yieldContent('main'); ?>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php echo $__env->make('dashboard/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laragon\www\pengaduan-mpp\resources\views/dashboard/main.blade.php ENDPATH**/ ?>