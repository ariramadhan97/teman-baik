<!DOCTYPE html>
<html>

    <head>
        <title>Teman Baik</title>
    </head>

    <body>
        <h4>Kepada Yth. <br>
            <?php echo e($data['instansi']->nama_instansi); ?>


            <p>
                <?php echo e($data['aduan']); ?>

            </p>
            Banjarmasin, <?php echo e(date_format(date_create($data['tgl_aduan']), 'd F Y')); ?> <br>
            ttd, <br>
            <br>
            <?php echo $data['ttd']; ?>

            <br>
            <?php echo $data['nama']; ?>

            <br>
            <br>
            <?php echo $data['bukti_dukung']; ?>

        </h4>
        <hr>
        <small>Pengaduan ini dikirim melalui <?php echo e($data['penginput']); ?> di sistem aplikasi TEMAN BAIK</small><br>
        <small><b>Mohon balas pesan ini jika anda memiliki jawaban terhadap aduan yang diberikan</b></small>
    </body>

</html>
<?php /**PATH C:\laragon\www\pengaduan-mpp\resources\views/sendmail.blade.php ENDPATH**/ ?>