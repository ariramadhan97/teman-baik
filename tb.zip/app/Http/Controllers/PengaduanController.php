<?php

namespace App\Http\Controllers;

use App\Models\Pengaduan;
use App\Http\Requests\StorePengaduanRequest;
use App\Http\Requests\UpdatePengaduanRequest;
use App\Models\Instansi;
use Illuminate\Support\Facades\Storage;


class PengaduanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data['instansi'] = Instansi::all();
        $data['aduan'] = Pengaduan::with(['instansi', 'status'])->orderBy('tgl_aduan', 'asc')->paginate(5);
        return view('pengaduan', $data);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorePengaduanRequest $request)
    {
        $turnstile_secret     = '0x4AAAAAAAx-ewNeLhbUv8dWxisoCD94j-4';
        $turnstile_response   = $_POST['cf-turnstile-response'];
        $url                  = "https://challenges.cloudflare.com/turnstile/v0/siteverify";
        $post_fields          = "secret=$turnstile_secret&response=$turnstile_response";

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
        $response = curl_exec($ch);
        curl_close($ch);

        $response_data = json_decode($response);

        if ($response_data->success) {
            if ($request['penginput'] == 'admin') {
                $cred = $request->validate([
                    'tgl_aduan' => 'required',
                    'instansi' => 'required',
                    'nama' => 'required',
                    'nohp' => 'required',
                    'alamat' => 'required',
                    'isi_aduan' => 'required',
                    'bukti' => 'mimes:jpeg,png,pdf|file|max:3072',
                    'kertas' => 'required|image|file|max:3072'
                ]);

                $imageName = 'form_' . date("YmdHis") . '.' . $request->file('kertas')->getClientOriginalExtension();
                $eviden = 'evid_' . date("YmdHis") . '.' . $request->file('bukti')->getClientOriginalExtension();


                $data['tgl_aduan'] = $request['tgl_aduan'];
                $data['nama'] = strip_tags($cred['nama']);
                $data['id_instansi'] = $request['instansi'];
                $data['id_status'] = 1;
                $data['is_aduan'] = $request['jenisAduan'];
                $data['alamat'] = strip_tags($cred['alamat']);
                $data['telepon'] = $cred['nohp'];
                $data['aduan'] = strip_tags($cred['isi_aduan']);
                $data['penginput'] = $request['penginput'];
                $data['nama_file'] = $imageName;
                $data['nama_file_eviden'] = $eviden;
                $data['samarkan'] = $request['samarkan'];

                Pengaduan::create($data);
                Storage::disk('local')->put('public/doc/' . $imageName, file_get_contents($request->file('kertas')));
                Storage::disk('local')->put('public/eviden/' . $eviden, file_get_contents($request->file('bukti')));

                return redirect('/pengaduan')->with('success', 'Permohonan Berhasil di Input');
            } else if ($request['penginput'] == 'mandiri') {
                $image = $request['ttd'];
                $image = str_replace('data:image/png;base64,', '', $image);
                $image = str_replace(' ', '+', $image);
                $imageName = 'ttd_' . date("YmdHis") . '.' . 'png';

                $cred = $request->validate([
                    'nama' => 'required',
                    'nohp' => 'required',
                    'alamat' => 'required',
                    'isi_aduan' => 'required',
                    'bukti' => 'mimes:jpeg,png,pdf|file|max:3072'
                ]);

                $eviden = 'evid_' . date("YmdHis") . '.' . $request->file('bukti')->getClientOriginalExtension();

                $data['tgl_aduan'] = date('Y-m-d');
                $data['nama'] = strip_tags($cred['nama']);
                $data['id_instansi'] = $request['instansi'];
                $data['id_status'] = 1;
                $data['is_aduan'] = $request['jenisAduan'];
                $data['alamat'] = strip_tags($cred['alamat']);
                $data['telepon'] = $cred['nohp'];
                $data['aduan'] = strip_tags($cred['isi_aduan']);
                $data['penginput'] = 'mandiri';
                $data['nama_file'] = $imageName;
                $data['nama_file_eviden'] = $eviden;
                $data['samarkan'] = $request['samarkan'];

                Pengaduan::create($data);
                Storage::disk('local')->put('public/doc/' . $imageName, base64_decode($image));
                Storage::disk('local')->put('public/eviden/' . $eviden, file_get_contents($request->file('bukti')));

                return redirect('/form')->with('success', 'Permohonan Berhasil Dikirim');
            }
        } else {
            return redirect('/form')->with('success', 'Permohonan Gagal Dikirim');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Pengaduan $pengaduan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Pengaduan $pengaduan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatePengaduanRequest $request, Pengaduan $pengaduan)
    {
        //
        Pengaduan::where('id', $pengaduan->id)->update([
            'jawaban' => $request->jawaban,
            'id_status' => 3
        ]);

        //window . open('https://wa.me/' + nohp + '?text=Berdasarkan pengaduan Bapak/Ibu ' + nama_pengadu + ' pada tanggal ' + tgl_aduan + nama_instansi_send + '%0ABerikut tanggap dari instansi terkait:%0A"' + jawaban_aduan + '"', '_blank');

        $token = env("WA_TOKEN", null);
        $instance_id = env("WA_ID", null);
        $msg = "Terima Kasih sudah menghubungi TEMAN BAIK (TEMpat penyampaiAN Berbagai Aduan di mal pelayanan publIK).%0A%0ABerdasarkan Permohonan ";
        if ($pengaduan->is_aduan) {
            $msg .= "Pengaduan ";
        } else {
            $msg .= "Informasi ";
        }
        $msg .= "yang Bapak/Ibu " . strtoupper($pengaduan->nama) . " sampaikan pada tanggal " . date_format(date_create($pengaduan->tgl_aduan), "d/m/Y") . " ke Instansi " . $pengaduan->instansi->nama_instansi . ",%0A%0A";
        $msg .= "Dapat kami sampaikan sebagai berikut :%0A";
        $msg .= $request->jawaban;

        $jid = "62" . substr($pengaduan->telepon, 1) . "@s.whatsapp.net";
        $url = "https://app.multichat.id/api/v1/send-text?token=" . $token . "&instance_id=" . $instance_id . "&jid=" . $jid . "&msg=" . $msg;
        $ch = curl_init($url);
        $respon = curl_exec($ch);
        if (curl_error($ch)) {
            die('Error:' . curl_error($ch));
        }
        curl_close($ch);

        return $respon;
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Pengaduan $pengaduan)
    {
        //
    }
}
