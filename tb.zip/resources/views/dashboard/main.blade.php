@include('dashboard/header')

<!-- Begin Page Content -->
<div class="container-fluid">

    @yield('main')

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

@include('dashboard/footer')
